<?php
ob_start();
session_start();
$con=mysqli_connect("localhost","root","","Inventory");
//if ($con) {
	# code...
	//echo "well connected";
/*}
else
{
	echo "no connection ";
}
*/
?>